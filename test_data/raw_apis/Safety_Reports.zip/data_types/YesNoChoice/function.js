function(ellipsis) {
  ellipsis.success([
  { id: "Yes", label: "Yes" },
  { id: "No", label: "No" }
]);
}
