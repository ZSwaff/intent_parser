**{successResult.heading}**
{for event in successResult.items}
- {event.formattedEvent}
{endfor}
