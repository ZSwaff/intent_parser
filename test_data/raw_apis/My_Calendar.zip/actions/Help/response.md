Ellipsis can show you what's happening on your calendar today, and send reminders when events are about to begin. (This skill requires access to your Google Calendar.)

**Actions:**
- `what's on my calendar today` — show your agenda (list all events) for the rest of the day
- `what's on my calendar now` — show any events happening now or in the next 10 minutes
- `setup my calendar` — set up the skill to send you your agenda on weekdays, and send you reminders before events begin
