Ellipsis will participate in your discussions when you say certain words or use certain emoji.

If you say **hurray!** or :tada:, Ellipsis will celebrate too. Or say **…go bananas** or **…:banana:** to get Ellipsis really excited.

When you use a sad face like :disappointed: or :slightly_frowning_face:, Ellipis will express concern.

You can also say **hi @ellipsis**, and **thanks @ellipsis**.