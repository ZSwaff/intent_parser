function(ellipsis) {
  "use strict"; 
const RandomResponse = require('ellipsis-random-response');
ellipsis.success(RandomResponse.responseWithEmoji('disappointed'));
}
