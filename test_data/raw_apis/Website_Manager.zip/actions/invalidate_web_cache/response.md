{if successResult.successFlag}
I am invalidating the website cache. This is will take few minutes.  
The invalidator id is {successResult.data.Invalidation.Id}
{else}
I failed to invalidate the website cache.  
Here is the error I am getting:  
```
{successResult.error}
```
{endif}