function(ellipsis) {
  "use strict";

const AWS = require('aws-sdk');

const distributionId = 'E1SM07BDVFPUO0';
const invalidateList = ['/*'];

const cloudfront = new AWS.CloudFront(/*new AWS.Config(ellipsis.aws.default)*/);

const options = {
  DistributionId: distributionId,
  InvalidationBatch: {
    CallerReference: Date.now().toString(),
    Paths: { Quantity: invalidateList.length, Items: invalidateList }
	}
};

cloudfront.createInvalidation(options, (err, data) => {
  ellipsis.success({
    successFlag: (err === null || err === undefined),
    error: err,
    data: data
  });
  
});
}
