{successResult.title}:
{for item in successResult.results}
**[{item.name}]({item.url})**  
> {item.snippet}  
>  
{endfor}