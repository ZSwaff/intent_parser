{for item in successResult.value}
*{item.providerName}* — [{item.name}]({item.url})
>{item.description}
{endfor}