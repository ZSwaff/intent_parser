The web search actions help you get quick answers from the web using Bing. Here are some examples of the 4 different actions:

- Try **search for bananas** to see the top search results for a phrase.
- Try **image for pandas in the snow** to get a quick image.
- Try **spell precotious** to check how to spell a word.
- Try **news for escape from the zoo** to see headlines for a particular topic.
