I can help your team deal with time zones. If you say a time of day in conversation, I can chime in and convert it to a second time zone. I can also tell you what time it is right now in a particular place.

Try saying **That meeting is at 12:00pm** or **What time is it in Toronto?**