Ellipsis can help your team keep track of who’s at work and who’s not. This skill requires Google Calendar.

**Examples:**
- `who's away today` — list today's absences
- `tell everyone I will be away` — record an absence

For more, say:
- `shared calendar guide` — how to use this skill, with more examples
- `shared calendar how to set up`
