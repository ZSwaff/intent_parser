**How to set up the Google Calendar skill:**  
This skill requires Google Calendar, and that you already have a single, shared vacation calendar that everyone can access.

To get started, say `shared calendar setup`. (I will ask you some questions to set the team’s shared calendar, and to schedule daily announcements in a particular channel.)

For an introduction to this skill, tell me `shared calendar help`.
