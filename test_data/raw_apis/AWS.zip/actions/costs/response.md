**AWS expenses money:** 

**This month:** {successResult.latest.currency} {successResult.latest.amount}

**Last month:** {successResult.secondLatest.currency} {successResult.secondLatest.amount}
