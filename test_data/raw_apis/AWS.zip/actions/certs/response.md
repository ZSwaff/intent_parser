**Your certificates:**

{for cert in successResult}
- `{cert.identifier}` — expires {cert.expiration}
{endfor}
