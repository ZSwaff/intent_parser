**Your certificates expiring soon:**

{for cert in successResult}
- `{cert.identifier}` — expires {cert.expiration}
{endfor}
