**S3 buckets:** 

{for bucket in successResult.Buckets}
- {bucket.Name}
{endfor}
