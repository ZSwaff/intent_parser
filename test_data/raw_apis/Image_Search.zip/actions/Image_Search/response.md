{for image in successResult.value}
  {image.contentUrl}
{endfor}