Google results for "{input}":

{for result in successResult}
1. [{result.text}]({result.link})
{endfor}