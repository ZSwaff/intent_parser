**{successResult.word}** _({successResult.category}):_

{successResult.definition}
