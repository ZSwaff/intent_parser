Ellipsis runs standup meetings for your team by asking people questions and building a summary for the team to see.  

**Getting started**  
1. Install the Standup skill
1. Type `setup standup` in a message to Ellipsis. It will ask you a few questions.
1. You are done!

**Using it**  
Once setup is complete, every weekday at the check-in time, Ellipsis will privately message each member of the #standup channel (or whatever channel you chose during setup) and ask three questions:
1. What did you accomplish yesterday?
1. What is the most important thing for you to accomplish today?
1. What else are you working on today, if anything?
1. What is blocking you at the moment?

At publishing time (10:00 am in our example), Ellipsis will print a report with everyone's answers to the standup channel.

For more help with this skill, type `@ellipsis standup faq`
