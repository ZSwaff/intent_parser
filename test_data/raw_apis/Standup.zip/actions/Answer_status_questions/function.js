function(yesterday, today, today2, blockers, channel, ellipsis) {
  const RandomResponse = require('ellipsis-random-response');
ellipsis.success(RandomResponse.responseWithEmoji("understood"));
}
