{for project in successResult}
- **{project.name}** {project.description}
{endfor}