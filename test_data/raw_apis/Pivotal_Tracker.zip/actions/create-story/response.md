OK, I created a new story at {successResult.url}

**Name: {successResult.name}**

Description: {successResult.description}

Project: {project.label}

