👥 {successResult.prompt}  

{for meeting in successResult.meetings}

───  

{meeting.employeeInfo}  
{meeting.event}

{endfor}