👥 OK 👍. You can:  
- add more at any time by typing `…add 1:1`
- remove a meeting by typing `…remove 1:1`
- add stuff to the 1:1 agendas `…add to next 1:1 agenda`