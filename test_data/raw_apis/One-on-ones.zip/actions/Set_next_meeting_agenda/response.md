👥 OK, I've updated the agenda to be:

```
{agenda}
```  

See the calendar event [here]({successResult})