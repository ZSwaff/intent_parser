👥 Meeting agenda for {successResult.event}:

```
{successResult.description}  
```  
