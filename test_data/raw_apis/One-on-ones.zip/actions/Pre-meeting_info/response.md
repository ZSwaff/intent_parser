{successResult.description}  

[View in calendar]({successResult.link})
