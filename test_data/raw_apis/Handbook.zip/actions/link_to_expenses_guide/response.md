Link to Msg:
https://seejanefarm.slack.com/files/jeffboes/F2LASC3N3/160927_sjf_expenses_guide_v1.pptx  
Link to Box:
https://seejanefarm.app.box.com/files/0/f/11505243196/Expenses  