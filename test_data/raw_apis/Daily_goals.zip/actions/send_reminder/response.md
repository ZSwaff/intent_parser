You said your goals for today were:  
> {successResult.goals}