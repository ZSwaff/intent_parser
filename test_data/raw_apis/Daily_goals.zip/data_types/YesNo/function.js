function(ellipsis) {
  ellipsis.success([
  { id: "Yes", label: "Yes", icon: ":thumbsup:" },
  { id: "No", label: "No", icon: ":thumbsdown:" }
]);
}
