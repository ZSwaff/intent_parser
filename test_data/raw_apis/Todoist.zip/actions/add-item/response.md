Ok, I added the following task:

**Task:** {taskName}

**Due:** {dueDate}

**Project:** {project.label}

You can view it at: https://todoist.com/showTask?id={successResult}