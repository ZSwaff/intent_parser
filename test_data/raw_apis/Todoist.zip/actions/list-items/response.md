{for item in successResult.items}
- {item.content} is due {item.due_date_utc}
{endfor}