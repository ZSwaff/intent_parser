{for project in successResult.projects}
- {project.name}
{endfor}