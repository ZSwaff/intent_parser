This is what I know about purchasing:  

We will all be using Plenty’s Purchasing & Procurement Department for all purchasing needs, excluding travel and meal expenses. The department plans on handling all internal orders for Engineering, R&D, and Farm Ops to start, however will process any orders that flow through the system as we continually educate and improve our internal purchasing process.

Keep the following in mind when placing orders. 
-    Your approver will need to approve your spending before the buyer can place an order. 
-    Once approved the buyer will receive your order and begin to process we ask that you allow one working day for orders to be placed with appropriate vendors.
-    Once the order has been placed the desired vendor will process and begin to fulfill the order, from the time the order has been processed to the time it has been handed over to a carrier (shipping and logistics company) the buyer will monitor and control your orders. This time is considered lead time and is something the buyer can’t control. Please keep this in mind when placing your internal orders.
-    Once the order has been handed over from the desired vendor to the carrier till the time it arrives at desired location our shipping and receiving department will monitor and control your order. 
-    Once the order has been delivered to a Plenty facility or site a trained individual will appropriately receive and deliver or notify that one’s order has been delivered and revived.

The following is the link for the Purchase Order Request form which is used for the budget approval process. https://app.smartsheet.com/b/form/9ee691d8d7d74b38925793a371f9eaa9